package back.inventorydancer;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;

/**
 * Plays once per launch when the title screen first appears.
 * Default: she teleports in over a dimmed screen, says "CAPRI ONLINE", then teleports out.
 * Optional: put your own square 128x128 frames at assets/inventorydancer/textures/gui/intro/frame_00.png,
 * frame_01.png, ... (in the mod or in a resource pack) and they play instead of the still image.
 * Optional: put your own music at assets/inventorydancer/sounds/startup_music.ogg and it plays with the intro.
 * Nothing is bundled for either.
 */
public final class CapriIntro {
    private CapriIntro() {}

    // ---- Tweak these ----
    private static final long IN_MS = 500, HOLD_MS = 1800, OUT_MS = 500;
    private static final int FRAME_SIZE = 128;   // custom frames must be 128x128
    private static final int FPS = 12;           // custom frame speed
    private static final int DIM = 0xB0;         // how dark the screen gets (0..255)
    // ---------------------

    private static boolean started, done, holdSoundPlayed, outSoundPlayed;
    private static long start;
    private static int frames = 0;

    private static Identifier frameId(int n) {
        return Identifier.of("inventorydancer", String.format("textures/gui/intro/frame_%02d.png", n));
    }

    private static float ease(float p) {
        p = Math.max(0f, Math.min(1f, p));
        return p * p * (3f - 2f * p);
    }

    public static void begin() {
        if (started) return;
        started = true;
        start = System.currentTimeMillis();
        ResourceManager rm = MinecraftClient.getInstance().getResourceManager();
        int n = 0;
        while (n < 120 && rm.getResource(frameId(n)).isPresent()) n++;
        frames = n;
        CapriSounds.play(CapriSounds.TELEPORT_IN);
        if (rm.getResource(Identifier.of("inventorydancer", "sounds/startup_music.ogg")).isPresent()) {
            CapriSounds.play(CapriSounds.STARTUP_MUSIC);
        }
    }

    public static void draw(DrawContext ctx, TextRenderer tr, int w, int h) {
        if (!started || done) return;
        long now = System.currentTimeMillis();
        long t = now - start;
        float amount, dim;
        if (t < IN_MS) {
            float e = ease(t / (float) IN_MS);
            amount = 1f - e;
            dim = e;
        } else if (t < IN_MS + HOLD_MS) {
            amount = 0f;
            dim = 1f;
            if (!holdSoundPlayed) {
                holdSoundPlayed = true;
                CapriSounds.play(CapriSounds.JOIN);
            }
        } else if (t < IN_MS + HOLD_MS + OUT_MS) {
            if (!outSoundPlayed) {
                outSoundPlayed = true;
                CapriSounds.play(CapriSounds.TELEPORT_OUT);
            }
            float e = ease((t - IN_MS - HOLD_MS) / (float) OUT_MS);
            amount = e;
            dim = 1f - e;
        } else {
            done = true;
            return;
        }

        int alpha = Math.round(DIM * dim);
        ctx.fill(0, 0, w, h, (alpha << 24) | 0x0A0A12);

        int size = Math.min(180, Math.round(h * 0.5f));
        int x = (w - size) / 2;
        int y = (h - size) / 2 - 12;
        if (frames > 0) {
            int idx = t < IN_MS ? 0 : (int) Math.min(frames - 1, (t - IN_MS) * FPS / 1000);
            CapriPet.drawCharacter(ctx, frameId(idx), FRAME_SIZE, x, y, size, amount, now);
        } else {
            CapriPet.drawCharacter(ctx, x, y, size, amount, now);
        }

        int ta = Math.round(255 * dim);
        if (ta > 8) {
            var m = ctx.getMatrices();
            String title = "CAPRI ONLINE";
            m.pushMatrix();
            m.translate(w / 2f, y + size + 6);
            m.scale(2f, 2f);
            ctx.drawText(tr, title, -tr.getWidth(title) / 2, 0, (ta << 24) | 0xFF2A55, true);
            m.popMatrix();
            String note = "Fan-made, non-commercial. Not affiliated with CD Projekt Red, Studio Trigger, or Netflix.";
            ctx.drawText(tr, note, (w - tr.getWidth(note)) / 2, h - 14, (ta << 24) | 0x8A8A99, false);
        }
    }
}
