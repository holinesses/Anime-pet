package back.inventorydancer;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Sound effects. The files live in assets/inventorydancer/sounds/ and are mapped in sounds.json. */
public final class CapriSounds {
    private CapriSounds() {}

    public static final SoundEvent PEEK_IN = ev("peek_in");
    public static final SoundEvent PEEK_OUT = ev("peek_out");
    public static final SoundEvent TALK = ev("talk");
    public static final SoundEvent HURT = ev("hurt");
    public static final SoundEvent ALERT = ev("alert");
    public static final SoundEvent DEATH = ev("death");
    public static final SoundEvent ADVANCEMENT = ev("advancement");
    public static final SoundEvent JOIN = ev("join");
    public static final SoundEvent TELEPORT_OUT = ev("teleport_out");
    public static final SoundEvent TELEPORT_IN = ev("teleport_in");

    private static final float VOLUME = 0.7f; // overall loudness of her sounds

    private static SoundEvent ev(String name) {
        return SoundEvent.of(Identifier.of("inventorydancer", name));
    }

    public static void play(SoundEvent event) {
        if (event == null) return;
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.ui(event, 1.0f, VOLUME));
    }
}
