package back.inventorydancer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.WeakHashMap;

public class InventoryDancer implements ClientModInitializer {

    // What she says. Edit freely.
    private static final String[] JOIN = {"Capri online. Let's go.", "I'm in. Don't waste my time."};
    private static final String[] DEATH = {"Ouch. That one's on you.", "Flatlined. Again?", "Respawn. Try not to repeat that."};
    private static final String[] HURT = {"Hey! Watch it.", "That hurt me too, you know.", "Careful out there."};
    private static final String[] LOW = {"You're nearly gone. Eat something!", "Few hearts left. Be smart.", "Low health. Don't be a hero."};
    private static final String[] ADVANCEMENT = {"Nice one. Progress!", "Look at you, unlocking things.", "Not bad. Not bad at all."};

    private static final Random RNG = new Random();
    private static final Map<String, Long> LAST = new HashMap<>();
    private static final Set<Screen> SEEN = Collections.newSetFromMap(new WeakHashMap<>());
    private static float lastHealth = -1f;

    @Override
    public void onInitializeClient() {
        // Menus and the inventory: sitting + teleporting, peeking, reactions
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            boolean first = SEEN.add(screen);
            if (first && screen instanceof DeathScreen) {
                say("death", DEATH, 0, CapriSounds.DEATH);
            }
            if (first && screen instanceof InventoryScreen) {
                CapriPet.resetSit();
            }
            ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, delta) -> {
                MinecraftClient mc = MinecraftClient.getInstance();
                boolean inventory = s instanceof InventoryScreen;
                if (inventory) {
                    CapriPet.drawSitting(ctx, (InventoryScreen) s);
                }
                CapriPet.tickPeek(!inventory);
                CapriPet.drawPeek(ctx, s.width, s.height, mouseX, mouseY);
                CapriPet.drawReaction(ctx, mc.textRenderer, s.width, s.height);
            });
        });

        // In-game: she teleports in over the HUD to talk
        HudElementRegistry.addLast(Identifier.of("inventorydancer", "capri"), (ctx, tick) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.currentScreen != null || mc.options.hudHidden) return;
            CapriPet.drawReaction(ctx, mc.textRenderer, mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight());
        });

        // Joining a world
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> say("join", JOIN, 0, CapriSounds.JOIN));

        // Taking damage / low health
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            var p = client.player;
            if (p == null) {
                lastHealth = -1f;
                return;
            }
            float hp = p.getHealth();
            if (lastHealth >= 0f && hp < lastHealth - 0.01f && hp > 0f) {
                if (hp <= 6f) {
                    say("low", LOW, 25_000, CapriSounds.ALERT);
                } else if (RNG.nextInt(100) < 45) {
                    say("hurt", HURT, 12_000, CapriSounds.HURT);
                }
            }
            lastHealth = hp;
        });
    }

    /** Called by the toast mixin when an advancement pops up. */
    public static void onAdvancement() {
        say("adv", ADVANCEMENT, 3_000, CapriSounds.ADVANCEMENT);
    }

    private static void say(String key, String[] lines, long cooldownMs, SoundEvent sound) {
        long now = System.currentTimeMillis();
        if (now - LAST.getOrDefault(key, 0L) < cooldownMs) return;
        LAST.put(key, now);
        CapriPet.react(lines[RNG.nextInt(lines.length)], sound);
    }
}
