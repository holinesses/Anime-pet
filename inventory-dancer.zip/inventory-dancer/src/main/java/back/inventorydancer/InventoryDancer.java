package back.inventorydancer;

import back.inventorydancer.mixin.HandledScreenAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.util.Identifier;

public class InventoryDancer implements ClientModInitializer {

    // ---- Tweak these ----
    private static final int SIZE = 120;            // on-screen size in GUI pixels
    private static final float SEAT_X = 0.50f;      // where she "sits" inside the image (0..1)
    private static final float SEAT_Y = 0.68f;
    private static final int OFFSET_X = 0;          // move left/right (relative to inventory center)
    private static final int OFFSET_Y = 6;          // move up/down (positive = sinks into the panel)
    private static final float BPM = 110f;          // dance speed
    private static final float SWAY = 0.10f;        // rotation amount in radians
    private static final float BOUNCE = 0.04f;      // squash and stretch amount
    // ---------------------

    private static final Identifier TEXTURE = Identifier.of("inventorydancer", "textures/gui/dancer.png");
    private static final long START = System.nanoTime();

    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof InventoryScreen inv) {
                ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, delta) -> draw(ctx, inv));
            }
        });
    }

    private static void draw(DrawContext ctx, InventoryScreen screen) {
        HandledScreenAccessor acc = (HandledScreenAccessor) screen;
        float pivotX = acc.inventorydancer$getX() + acc.inventorydancer$getBackgroundWidth() / 2f + OFFSET_X;
        float pivotY = acc.inventorydancer$getY() + OFFSET_Y;

        float t = (System.nanoTime() - START) / 1_000_000_000f;
        float beat = t * (float) (2 * Math.PI) * (BPM / 60f);

        float angle = (float) Math.sin(beat * 0.5f) * SWAY;
        float scaleY = 1f + (float) Math.sin(beat) * BOUNCE;
        float scaleX = 1f - (float) Math.sin(beat) * BOUNCE * 0.5f;

        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(pivotX, pivotY);
        m.rotate(angle);
        m.scale(scaleX, scaleY);
        ctx.drawTexture(
            RenderPipelines.GUI_TEXTURED,
            TEXTURE,
            Math.round(-SIZE * SEAT_X), Math.round(-SIZE * SEAT_Y),
            0f, 0f,
            SIZE, SIZE,
            256, 256,
            256, 256
        );
        m.popMatrix();
    }
}
