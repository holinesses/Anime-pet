package back.inventorydancer;

import back.inventorydancer.mixin.HandledScreenAccessor;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

import java.util.Random;

/**
 * The pet. Three behaviours:
 *  - sits on top of the inventory and teleports along its edge every so often
 *  - teleports in at the bottom right of the screen to say something (reactions)
 *  - peeks in from the edges of menus
 * The teleport glitch effect is drawn in code (sliced sprite, glitch bars, shards, light column).
 */
public final class CapriPet {
    private CapriPet() {}

    public enum Edge { BOTTOM, TOP, LEFT, RIGHT }

    // ---- Tweak these ----
    private static final int SIZE = 120;                 // sitting / peeking size in GUI pixels
    private static final int REACT_SIZE = 100;           // size when she teleports in to talk
    private static final float SEAT_X = 0.50f;           // where she "sits" inside the image (0..1)
    private static final float SEAT_Y = 0.76f;
    private static final int SIT_OFFSET_Y = 1;
    private static final int SIT_SPREAD = 54;            // how far left/right she can teleport on the inventory edge
    private static final int TP_SECONDS_MIN = 30;        // gap between teleports while the inventory is open
    private static final int TP_SECONDS_EXTRA = 40;
    private static final long TP_OUT_MS = 380, TP_IN_MS = 380;
    private static final long REACT_IN_MS = 380, REACT_OUT_MS = 380, REACT_HOLD_MS = 3200;
    private static final float VISIBLE = 0.70f;          // how much of her shows when peeking
    private static final long PEEK_IN_MS = 380, PEEK_OUT_MS = 420, PEEK_HOLD_MS = 2600;
    private static final int PEEK_MIN_SECONDS = 25;
    private static final int PEEK_EXTRA_SECONDS = 35;
    private static final float SHY_DISTANCE = 55f;       // she ducks away if your mouse gets this close
    // ---------------------

    private static final Identifier TEXTURE = Identifier.of("inventorydancer", "textures/gui/dancer.png");
    private static final Random RNG = new Random();
    private static final int SLICES = 16; // 256 / 16 = 16 texel rows per slice

    // ======================= drawing helpers =======================

    private static float ease(float p) {
        p = Math.max(0f, Math.min(1f, p));
        return p * p * (3f - 2f * p);
    }

    private static float hash(long a, int b) {
        long h = a * 0x9E3779B97F4A7C15L + b * 0xC2B2AE3D27D4EB4FL;
        h ^= (h >>> 29);
        h *= 0xBF58476D1CE4E5B9L;
        h ^= (h >>> 32);
        return (h & 0xFFFFFF) / (float) 0x1000000;
    }

    private static void sprite(DrawContext ctx, int x, int y, int size) {
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TEXTURE, x, y, 0f, 0f, size, size, 256, 256, 256, 256);
    }

    /** amount: 0 = fully there, 1 = fully gone. Used for both teleporting out (0 to 1) and in (1 to 0). */
    static void drawCharacter(DrawContext ctx, int x, int y, int size, float amount, long now) {
        drawCharacter(ctx, TEXTURE, 256, x, y, size, amount, now);
    }

    /** Same effect for any square texture (texSize = its width and height in pixels). */
    static void drawCharacter(DrawContext ctx, Identifier tex, int texSize, int x, int y, int size, float amount, long now) {
        if (amount <= 0.001f) {
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, tex, x, y, 0f, 0f, size, size, texSize, texSize, texSize, texSize);
            return;
        }
        long seed = now / 70; // the glitch pattern changes about 14 times a second

        // sprite in horizontal slices: random ones disappear and the rest shift sideways
        if (amount < 1f) {
            for (int i = 0; i < SLICES; i++) {
                if (hash(seed, i) < amount) continue;
                float r2 = hash(seed + 977, i);
                int shift = Math.round((r2 - 0.5f) * 2f * amount * size * 0.4f);
                int y0 = y + Math.round(i * size / (float) SLICES);
                int y1 = y + Math.round((i + 1) * size / (float) SLICES);
                int rowH = texSize / SLICES;
                ctx.drawTexture(RenderPipelines.GUI_TEXTURED, tex, x + shift, y0, 0f, (float) (i * rowH),
                    size, y1 - y0, texSize, rowH, texSize, texSize);
            }
        }

        // glitch bars
        for (int k = 0; k < 4; k++) {
            int bw = Math.round(size * (0.25f + 0.6f * hash(seed + k * 13L, 303)));
            int bx = x + Math.round(hash(seed + k * 17L, 202) * (size - bw));
            int by = y + Math.round(hash(seed + k * 31L, 101) * size);
            ctx.fill(bx, by, bx + bw, by + 3, (k % 2 == 0) ? 0xCCFF2A55 : 0xCC2AFF77);
        }

        // shards scatter outward as she vanishes and rush back in as she appears
        var m = ctx.getMatrices();
        float cx = x + size / 2f, cy = y + size * 0.45f;
        for (int i = 0; i < 14; i++) {
            float a = hash(i * 7L, 11) * 6.2832f;
            float spd = 0.4f + 0.8f * hash(i * 7L, 12);
            float d = amount * size * spd * 0.9f;
            int col = (i % 3 == 0) ? 0xFFFFFFFF : (i % 3 == 1 ? 0xFFFF2A55 : 0xFF7A3CFF);
            m.pushMatrix();
            m.translate(cx + (float) Math.cos(a) * d, cy + (float) Math.sin(a) * d);
            m.rotate(a + amount * 3f);
            ctx.fill(-2, -4, 2, 4, col);
            m.popMatrix();
        }

        // the red column of light, strongest right at the moment she vanishes / appears
        if (amount > 0.75f) {
            float k = Math.min(1f, (amount - 0.75f) / 0.25f);
            int hw = Math.round(2 + 5 * k);
            int mx = Math.round(x + size * 0.5f);
            int top = y - Math.round(size * 0.15f);
            int bot = y + size + Math.round(size * 0.1f);
            ctx.fill(mx - hw - 1, top, mx + hw + 1, bot, 0xFF7A3CFF);
            ctx.fill(mx - hw, top, mx + hw, bot, 0xFFFF2A55);
            ctx.fill(mx - 1, top, mx + 1, bot, 0xFFFFFFFF);
        }
    }

    // ======================= sitting on the inventory =======================

    private static int sitPos = 0;        // -1 left, 0 center, 1 right
    private static int sitPending = 0;
    private static long sitTpStart = 0;   // 0 = not teleporting
    private static boolean sitSwitched;
    private static long sitNextAt = System.currentTimeMillis() + 15_000;

    /** Called when an inventory screen opens. */
    public static void resetSit() {
        sitTpStart = 0;
        sitNextAt = System.currentTimeMillis() + 15_000;
    }

    public static void drawSitting(DrawContext ctx, InventoryScreen screen) {
        long now = System.currentTimeMillis();
        float amount = 0f;
        if (sitTpStart != 0) {
            long t = now - sitTpStart;
            if (t < TP_OUT_MS) {
                amount = ease(t / (float) TP_OUT_MS);
            } else if (t < TP_OUT_MS + TP_IN_MS) {
                if (!sitSwitched) {
                    sitSwitched = true;
                    sitPos = sitPending;
                    CapriSounds.play(CapriSounds.TELEPORT_IN);
                }
                amount = 1f - ease((t - TP_OUT_MS) / (float) TP_IN_MS);
            } else {
                sitTpStart = 0;
            }
        } else if (now >= sitNextAt) {
            int next;
            do { next = RNG.nextInt(3) - 1; } while (next == sitPos);
            sitPending = next;
            sitTpStart = now;
            sitSwitched = false;
            sitNextAt = now + (TP_SECONDS_MIN + RNG.nextInt(TP_SECONDS_EXTRA)) * 1000L;
            CapriSounds.play(CapriSounds.TELEPORT_OUT);
        }

        HandledScreenAccessor acc = (HandledScreenAccessor) screen;
        float px = acc.inventorydancer$getX() + acc.inventorydancer$getBackgroundWidth() / 2f + sitPos * SIT_SPREAD;
        float py = acc.inventorydancer$getY() + SIT_OFFSET_Y;
        drawCharacter(ctx, Math.round(px - SIZE * SEAT_X), Math.round(py - SIZE * SEAT_Y), SIZE, amount, now);
    }

    // ======================= reactions (teleport in, talk, teleport out) =======================

    // Where she can teleport in to talk (fractions of the free screen area: x, y). Edit freely.
    private static final float[][] SPOTS = {
        {0.97f, 0.97f}, // bottom right
        {0.03f, 0.60f}, // left, above the chat
        {0.97f, 0.55f}, // right, middle
        {0.03f, 0.12f}, // top left
        {0.97f, 0.10f}, // top right
        {0.25f, 0.08f}, // top, left of center
        {0.75f, 0.08f}, // top, right of center
    };
    private static int rSpot = -1;
    private static float rFx, rFy;
    private static boolean rActive;
    private static String rLine;
    private static long rStart, rHold;
    private static SoundEvent rSound;
    private static boolean rSoundPlayed, rOutPlayed;

    public static void react(String text, SoundEvent sound) {
        rActive = true;
        rLine = text;
        rHold = REACT_HOLD_MS + 35L * text.length();
        rStart = System.currentTimeMillis();
        rSound = sound;
        rSoundPlayed = false;
        rOutPlayed = false;
        int next;
        do { next = RNG.nextInt(SPOTS.length); } while (next == rSpot); // never the same spot twice in a row
        rSpot = next;
        rFx = SPOTS[next][0];
        rFy = SPOTS[next][1];
        CapriSounds.play(CapriSounds.TELEPORT_IN);
    }

    public static void drawReaction(DrawContext ctx, TextRenderer tr, int w, int h) {
        if (!rActive) return;
        long now = System.currentTimeMillis();
        long t = now - rStart;
        float amount;
        boolean talking = false;
        if (t < REACT_IN_MS) {
            amount = 1f - ease(t / (float) REACT_IN_MS);
        } else if (t < REACT_IN_MS + rHold) {
            amount = 0f;
            talking = true;
            if (!rSoundPlayed) {
                rSoundPlayed = true;
                CapriSounds.play(rSound);
            }
        } else if (t < REACT_IN_MS + rHold + REACT_OUT_MS) {
            if (!rOutPlayed) {
                rOutPlayed = true;
                CapriSounds.play(CapriSounds.TELEPORT_OUT);
            }
            amount = ease((t - REACT_IN_MS - rHold) / (float) REACT_OUT_MS);
        } else {
            rActive = false;
            return;
        }

        int size = REACT_SIZE;
        int x = Math.round(rFx * (w - size));
        int y = Math.round(rFy * (h - size));
        drawCharacter(ctx, x, y, size, amount, now);

        if (talking && rLine != null) {
            int bw = tr.getWidth(rLine) + 14;
            int bh = 18;
            boolean onRight = x + size / 2 > w / 2;
            int bx = onRight ? Math.max(4, x - bw - 2) : Math.min(x + size + 2, w - bw - 4); // bubble on the roomier side
            int by = Math.max(4, Math.min(y + Math.round(size * 0.30f), h - bh - 4));
            ctx.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, 0xFFE0204A);
            ctx.fill(bx, by, bx + bw, by + bh, 0xF0101018);
            ctx.drawText(tr, rLine, bx + 7, by + 5, 0xFFFFFFFF, false);
        }
    }

    // ======================= peeking from the edges (menus) =======================

    private static boolean pActive, pOutPlayed;
    private static Edge pEdge = Edge.BOTTOM;
    private static float pAlong = 0.5f, pTilt;
    private static long pStart;
    private static long nextPeekAt = System.currentTimeMillis() + 20_000;

    public static void tickPeek(boolean allowed) {
        long now = System.currentTimeMillis();
        if (pActive || rActive || !allowed || now < nextPeekAt) return;
        pEdge = Edge.values()[RNG.nextInt(4)];
        pAlong = 0.15f + RNG.nextFloat() * 0.7f;
        pTilt = pAlong < 0.5f ? -1f : 1f;
        pStart = now;
        pActive = true;
        pOutPlayed = false;
        CapriSounds.play(CapriSounds.PEEK_IN);
        nextPeekAt = now + (PEEK_MIN_SECONDS + RNG.nextInt(PEEK_EXTRA_SECONDS)) * 1000L;
    }

    private static float easeOutBack(float p) {
        p = Math.max(0f, Math.min(1f, p));
        float c1 = 1.70158f, c3 = c1 + 1f;
        float q = p - 1f;
        return 1f + c3 * q * q * q + c1 * q * q;
    }

    private static float peekProgress(long now) {
        long t = now - pStart;
        if (t < PEEK_IN_MS) return easeOutBack(t / (float) PEEK_IN_MS);
        if (t < PEEK_IN_MS + PEEK_HOLD_MS) return 1f;
        if (t < PEEK_IN_MS + PEEK_HOLD_MS + PEEK_OUT_MS) {
            if (!pOutPlayed) {
                pOutPlayed = true;
                CapriSounds.play(CapriSounds.PEEK_OUT);
            }
            return 1f - ease((t - PEEK_IN_MS - PEEK_HOLD_MS) / (float) PEEK_OUT_MS);
        }
        pActive = false;
        return 0f;
    }

    public static void drawPeek(DrawContext ctx, int w, int h, int mouseX, int mouseY) {
        if (!pActive) return;
        long now = System.currentTimeMillis();
        float prog = peekProgress(now);
        if (!pActive || prog <= 0f) return;

        float ax, ay, ang, dx, dy;
        switch (pEdge) {
            case TOP:
                ax = pAlong * w; ay = 0; ang = (float) Math.PI; dx = 0; dy = 1; break;
            case LEFT:
                ax = 0; ay = pAlong * h; ang = (float) (Math.PI / 2); dx = 1; dy = 0; break;
            case RIGHT:
                ax = w; ay = pAlong * h; ang = (float) (-Math.PI / 2); dx = -1; dy = 0; break;
            default:
                ax = pAlong * w; ay = h; ang = 0; dx = 0; dy = -1; break;
        }
        ang += (1f - Math.min(prog, 1f)) * 0.30f * pTilt; // tilts upright as she pops in
        float shown = SIZE * VISIBLE * prog;

        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(ax, ay);
        m.rotate(ang);
        sprite(ctx, Math.round(-SIZE / 2f), -Math.round(shown), SIZE);
        m.popMatrix();

        // shy: duck away when the mouse comes close
        if (prog > 0.95f) {
            float hx = ax + dx * shown * 0.6f;
            float hy = ay + dy * shown * 0.6f;
            float ddx = mouseX - hx, ddy = mouseY - hy;
            if (ddx * ddx + ddy * ddy < SHY_DISTANCE * SHY_DISTANCE) {
                pStart = now - (PEEK_IN_MS + PEEK_HOLD_MS); // jump to the leaving part
            }
        }
    }
}
