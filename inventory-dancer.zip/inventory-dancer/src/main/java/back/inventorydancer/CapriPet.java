package back.inventorydancer;

import back.inventorydancer.mixin.HandledScreenAccessor;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.util.Identifier;

import java.util.Random;

/** Draws the character: sitting on the inventory, peeking from screen edges, and reacting with a speech bubble. */
public final class CapriPet {
    private CapriPet() {}

    public enum Edge { BOTTOM, TOP, LEFT, RIGHT }

    // ---- Tweak these ----
    private static final int SIZE = 120;             // sprite size in GUI pixels
    private static final float VISIBLE = 0.62f;      // how much of her shows when peeking (0..1)
    private static final float SEAT_X = 0.50f;       // sitting pose anchor inside the image
    private static final float SEAT_Y = 0.76f;
    private static final int SIT_OFFSET_Y = 1;
    private static final long IN_MS = 450, OUT_MS = 450;
    private static final long PEEK_HOLD_MS = 2600;   // how long a peek stays
    private static final long REACT_HOLD_MS = 3200;  // base time a speech bubble stays
    private static final int PEEK_MIN_SECONDS = 25;  // gap between peeks
    private static final int PEEK_EXTRA_SECONDS = 35;
    private static final float SHY_DISTANCE = 55f;   // she ducks away if your mouse gets this close
    // ---------------------

    private static final Identifier TEXTURE = Identifier.of("inventorydancer", "textures/gui/dancer.png");
    private static final Random RNG = new Random();

    private static boolean active;
    private static Edge edge = Edge.BOTTOM;
    private static float along = 0.85f;
    private static String line;
    private static long start;
    private static long holdMs;
    private static long nextPeekAt = System.currentTimeMillis() + 20_000;

    private static void sprite(DrawContext ctx, int x, int y) {
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TEXTURE, x, y, 0f, 0f, SIZE, SIZE, 256, 256, 256, 256);
    }

    // ---------- sitting on top of the inventory ----------
    public static void drawSitting(DrawContext ctx, InventoryScreen screen) {
        HandledScreenAccessor acc = (HandledScreenAccessor) screen;
        float px = acc.inventorydancer$getX() + acc.inventorydancer$getBackgroundWidth() / 2f;
        float py = acc.inventorydancer$getY() + SIT_OFFSET_Y;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(px, py);
        sprite(ctx, Math.round(-SIZE * SEAT_X), Math.round(-SIZE * SEAT_Y));
        m.popMatrix();
    }

    // ---------- reactions ----------
    public static void react(String text) {
        edge = Edge.BOTTOM;
        along = 0.85f;
        line = text;
        holdMs = REACT_HOLD_MS + 35L * text.length();
        start = System.currentTimeMillis();
        active = true;
    }

    // ---------- peeking (menus only) ----------
    public static void tickPeek(boolean menuOpen) {
        long now = System.currentTimeMillis();
        if (active || !menuOpen || now < nextPeekAt) return;
        edge = Edge.values()[RNG.nextInt(4)];
        along = 0.15f + RNG.nextFloat() * 0.7f;
        line = null;
        holdMs = PEEK_HOLD_MS;
        start = now;
        active = true;
        nextPeekAt = now + (PEEK_MIN_SECONDS + RNG.nextInt(PEEK_EXTRA_SECONDS)) * 1000L;
    }

    private static float ease(float p) {
        p = Math.max(0f, Math.min(1f, p));
        return p * p * (3f - 2f * p);
    }

    private static float progress(long now) {
        long t = now - start;
        if (t < IN_MS) return ease(t / (float) IN_MS);
        if (t < IN_MS + holdMs) return 1f;
        if (t < IN_MS + holdMs + OUT_MS) return 1f - ease((t - IN_MS - holdMs) / (float) OUT_MS);
        active = false;
        return 0f;
    }

    public static void draw(DrawContext ctx, TextRenderer tr, int w, int h, int mouseX, int mouseY, boolean shy) {
        if (!active) return;
        long now = System.currentTimeMillis();
        float prog = progress(now);
        if (!active || prog <= 0f) return;

        float ax, ay, ang, dx, dy; // anchor on the edge, rotation, direction pointing into the screen
        switch (edge) {
            case TOP:
                ax = along * w; ay = 0; ang = (float) Math.PI; dx = 0; dy = 1; break;
            case LEFT:
                ax = 0; ay = along * h; ang = (float) (Math.PI / 2); dx = 1; dy = 0; break;
            case RIGHT:
                ax = w; ay = along * h; ang = (float) (-Math.PI / 2); dx = -1; dy = 0; break;
            default:
                ax = along * w; ay = h; ang = 0; dx = 0; dy = -1; break;
        }
        float shown = SIZE * VISIBLE * prog;

        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(ax, ay);
        m.rotate(ang);
        sprite(ctx, Math.round(-SIZE / 2f), -Math.round(shown));
        m.popMatrix();

        // shy: duck away when the mouse comes close (peeks only)
        if (shy && line == null && prog > 0.95f) {
            float hx = ax + dx * shown * 0.6f;
            float hy = ay + dy * shown * 0.6f;
            float ddx = mouseX - hx, ddy = mouseY - hy;
            if (ddx * ddx + ddy * ddy < SHY_DISTANCE * SHY_DISTANCE) {
                start = now - (IN_MS + holdMs); // jump to the "leaving" part
            }
        }

        // speech bubble
        if (line != null && prog > 0.8f) {
            int bw = tr.getWidth(line) + 14;
            int bh = 18;
            int bx = Math.max(4, Math.round(ax - SIZE / 2f - bw - 2));
            int by = Math.max(4, Math.min(Math.round(ay - 34), h - bh - 4));
            ctx.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, 0xFFE0204A);
            ctx.fill(bx, by, bx + bw, by + bh, 0xF0101018);
            ctx.drawText(tr, line, bx + 7, by + 5, 0xFFFFFFFF, false);
        }
    }
}
