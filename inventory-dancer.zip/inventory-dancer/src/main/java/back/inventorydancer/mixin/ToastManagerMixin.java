package back.inventorydancer.mixin;

import back.inventorydancer.InventoryDancer;
import net.minecraft.client.toast.AdvancementToast;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ToastManager.class)
public class ToastManagerMixin {
    @Inject(method = "add", at = @At("HEAD"))
    private void inventorydancer$onAdd(Toast toast, CallbackInfo ci) {
        if (toast instanceof AdvancementToast) {
            InventoryDancer.onAdvancement();
        }
    }
}
