package back.inventorydancer.mixin;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(HandledScreen.class)
public interface HandledScreenAccessor {
    @Accessor("x")
    int inventorydancer$getX();

    @Accessor("y")
    int inventorydancer$getY();

    @Accessor("backgroundWidth")
    int inventorydancer$getBackgroundWidth();
}
