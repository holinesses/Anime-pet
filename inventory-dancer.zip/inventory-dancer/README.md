# Inventory Dancer

A free, fan-made Minecraft (Fabric 1.21.11) mod. A character sits on top of your inventory, teleports along the edge of the inventory, peeks in from the edges of menus, plays little sound effects, and teleports in to react to joining a world, taking damage, low health, dying, and advancements.

## Disclaimer

Capri, Project Capricorn, and Cyberpunk: Edgerunners are the property of CD Projekt Red, Studio Trigger, and Netflix. This is a non-commercial, fan-made mod with no affiliation to or endorsement by the rights holders. Character artwork is not covered by this license. The mod is free and is never to be sold.
